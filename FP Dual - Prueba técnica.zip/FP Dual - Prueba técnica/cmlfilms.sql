-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-06-2022 a las 18:44:39
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cmlfilms`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cesta`
--

CREATE TABLE `cesta` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_article` int(11) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cesta`
--

INSERT INTO `cesta` (`id`, `id_user`, `id_article`, `type`) VALUES
(3, 6, 338953, 'FILM'),
(12, 2, 90534, 'PERSON'),
(15, 2, 125738, 'PERSON'),
(17, 2, 108, 'PERSON'),
(20, 3, 610133, 'FILM');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `films`
--

CREATE TABLE `films` (
  `id` int(11) NOT NULL,
  `adult` tinyint(1) NOT NULL,
  `overview` varchar(3500) NOT NULL,
  `release_date` varchar(10) NOT NULL,
  `original_title` varchar(200) NOT NULL,
  `language` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `popularity` double NOT NULL,
  `vote_content` int(11) NOT NULL,
  `video` tinyint(1) NOT NULL,
  `vote_average` double NOT NULL,
  `backdrop_path` varchar(1000) NOT NULL,
  `genre_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`genre_ids`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(60) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `email`, `password`) VALUES
(2, 'claribel', 'claribelgg0@gmail.com', '$argon2id$v=19$m=1024,t=1,p=1$Pg5nAzX9tjkBxmBdZzd+AA$xOACdiGMXfMUDLpyh3QkM5NDCJrBK/RYyrQ77fd2/Rs'),
(3, 'jensus', 'lacuentaconspam@gmial.com', '$argon2id$v=19$m=1024,t=1,p=1$1hfuD5kFdWJMFdOHGURVfQ$wFotyiokqsJc7Oc7zAcD1y+TAeQNRzUboVBhmYVW0SA'),
(4, 'raul', 'raul@gmail.com', '$argon2id$v=19$m=1024,t=1,p=1$k6ZsuvnAMGo+En1dFyqmgg$dS7YLcUrCTG2OJcGK7MqwTrJ0YJObzTpoh5RQPMaE48'),
(5, 'cancer23', 'josecancer@gmail.com', '$argon2id$v=19$m=1024,t=1,p=1$umEa7d8F1L/6BzLKQEI2zQ$iotNBehDEx6pmbBAR6qJK+XI+WdsaulkqAab8N7RTzE'),
(6, 'prueba', 'prueba@gmail.com', '$argon2id$v=19$m=1024,t=1,p=1$bULkOVu+NNghcVEke88ctg$3QK5VXPHSGZlPn8NbysfHB1J9tDRL1WTapSYWG+OX6w'),
(7, 'prueba1', 'claribelgg1@gmail.com', '$argon2id$v=19$m=1024,t=1,p=1$nCsz9hUh5dOzrw2KzshZlw$uwHiTHoTShxEG7FzWbKtnaHBJpmzKtrNdc2gObcLFVU');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cesta`
--
ALTER TABLE `cesta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cesta`
--
ALTER TABLE `cesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
