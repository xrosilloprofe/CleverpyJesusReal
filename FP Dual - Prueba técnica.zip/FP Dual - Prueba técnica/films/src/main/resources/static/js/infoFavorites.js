const imgLike='http://localhost:8080/img/with_like.png';
const imgNoLike='http://localhost:8080/img/without_like.png';
const img_not_found="http://assets.stickpng.com/images/5a461402d099a2ad03f9c997.png";

var peliculaSelecionada;
var idPeli=localStorage.peliid;
const like=document.querySelector("#like");

const contFilms=document.querySelector("#list1");
const contPersons=document.querySelector("#list2");

if (typeof sessionStorage.token !== 'undefined'){
    setInfo();
}else{
    window.location.href = "../index.html";
}



async function setInfo(){
     const url='http://localhost:8080/api/user/getFavorites';
            var request = await fetch(url, {
               method: 'GET',
               headers: {
                 'Accept': 'application/json',
                 'Content-Type': 'application/json',
                 'Authorization':sessionStorage.token
               },
             });

             const result = await request.json();

             if(result.type=='SUCCESS'){

                let films='';
                let image;
                result.info.films.forEach(element =>{
                        if(element["poster_path"]==null){
                            image=img_not_found;
                        }else{
                            image="https://image.tmdb.org/t/p/original/"+element["poster_path"];
                        }

                        films+='<article class="people">'+
                                        '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                                        '<div class="people_hover">'+
                                            '<p class="title">'+element["original_title"]+'</p>'+
                                            '<p class="descripcion"><b>'+element["status"]+'</b></p>'+
                                            '<buton class="btnShow" data-type="FILM" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                                        '</div>'+
                                    '</article>';
                    });
                    contFilms.innerHTML=films;


                    let persons='';
                    result.info.persons.forEach(element =>{
                            if(element["profile_path"]==null){
                                image=img_not_found;
                            }else{
                                image="https://image.tmdb.org/t/p/original/"+element["profile_path"];
                            }

                            persons+='<article class="people">'+
                                            '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                                            '<div class="people_hover">'+
                                                '<p class="title">'+element["name"]+'</p>'+
                                                '<p class="descripcion"><b>'+element["known_for_department"]+'</b></p>'+
                                                '<buton class="btnShow" data-type="PERSON" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                                            '</div>'+
                                        '</article>';
                        });
                        contPersons.innerHTML=persons;

                        const btnShow=document.querySelectorAll(".btnShow");
                        btnShow.forEach(btn =>{
                            btn.addEventListener("click",({target: {dataset}}) => {


                                if((String)(dataset.type)=="FILM"){
                                    localStorage.peliid=dataset.id;
                                    window.location.href = "../htmls/infoPeli.html";

                                }else if((String)(dataset.type)=="PERSON"){
                                    localStorage.personid=dataset.id;
                                    window.location.href = "../htmls/infoPerson.html";
                                }

                        	})
                        });


             }else{
                 alert(result.type+": "+result.code+", "+result.message);
             }

}



function setArticleCrew(person){
        let image;
        if(person["profile_path"]==null){
            image=img_not_found;
        }else{
            image="https://image.tmdb.org/t/p/original/"+person["profile_path"];
        }
    return '<article class="people">'+
                       '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                       '<div class="people_hover">'+
                           '<p class="title">'+person["name"]+'</p>'+
                           '<p class="descripcion"><b>'+person["job"]+'</b></p>'+
                           '<buton class="btnShow" data-id="'+person["id"]+'">INFORMACI&Oacute;N</buton>'+
                       '</div>'+
                   '</article>';
}