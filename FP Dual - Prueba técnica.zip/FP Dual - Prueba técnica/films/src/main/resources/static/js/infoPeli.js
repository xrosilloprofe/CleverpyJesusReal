const imgLike='http://localhost:8080/img/with_like.png';
const imgNoLike='http://localhost:8080/img/without_like.png';

const img_not_found="http://assets.stickpng.com/images/5a461402d099a2ad03f9c997.png";
var peliculaSelecionada;
var idPeli=localStorage.peliid;
const like=document.querySelector("#like");

const titleFilm=document.querySelector("#titleArticle");
const dateFilm=document.querySelector("#subtitle");
const img_peli=document.querySelector("#article_img");
const descripcion_peli=document.querySelector("#overview");
const contActors=document.querySelector("#list1");
const contCrews=document.querySelector("#list2");

if (typeof idPeli !== 'undefined'){
    setInfoPeli();
}else{
    window.location.href = "../index.html";
}
async function setInfoPeli(){

    var url='http://localhost:8080/api/film/'+idPeli;

    var request = await fetch(url, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
        });
        var result = await request.json();

         if(result.type=='SUCCESS'){
            peliculaSelecionada=result.info;
            await obtenerDatos();
        }else{

        }
}

async function obtenerDatos() {
	titleFilm.textContent=peliculaSelecionada["title"];
	dateFilm.textContent=peliculaSelecionada["release_date"];
	img_peli.src="https://image.tmdb.org/t/p/original/" + peliculaSelecionada["backdrop_path"];
	descripcion_peli.textContent=peliculaSelecionada["overview"];
	like.src=imgNoLike;

    if (typeof sessionStorage.token !== 'undefined') {
        const url='http://localhost:8080/api/user/getLike/'+peliculaSelecionada["id"];

        var request = await fetch(url, {
           method: 'GET',
           headers: {
             'Accept': 'application/json',
             'Content-Type': 'application/json',
             'Authorization':sessionStorage.token
           },
         });

         const result = await request.json();

         if(result.type=='SUCCESS'){
            if(result.info==true){
                like.src=imgLike;
            }else{
                like.src=imgNoLike;
            }
         }else{
             alert(result.type+": "+result.code+", "+result.message);
         }

        like.addEventListener("click",setLike);
    }
	setCredits();
}
async function setLike(){
        if (typeof sessionStorage.token !== 'undefined') {
        	const url='http://localhost:8080/api/user/setLike/'+peliculaSelecionada["id"]+'/FILM';

                    var request = await fetch(url, {
                       method: 'GET',
                       headers: {
                         'Accept': 'application/json',
                         'Content-Type': 'application/json',
                         'Authorization':sessionStorage.token
                       },
                     });

                     const result = await request.json();
                     if(result.type=='SUCCESS'){
                        if(like.src==imgLike){
                            like.src=imgNoLike
                        }else{
                            like.src=imgLike;
                        }
                     }else{
                         alert(result.type+": "+result.code+", "+result.message);
                     }
        }else{
            alert("Necesitas iniciar sesion");
        }


}
async function setCredits(){
    var url='http://localhost:8080/api/credits/'+idPeli;
    var request = await fetch(url, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
        });
        var result = await request.json();

         if(result.type=='SUCCESS'){
            var credits=result.info;
            let person='';
            let image;
            credits.cast.forEach(element =>{
                    if(element["profile_path"]==null|| typeof element["profile_path"]==='undefined'){
                        image=img_not_found;
                    }else{
                        image="https://image.tmdb.org/t/p/original/"+element["profile_path"];
                    }

                	person+='<article class="people">'+
                                    '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                                    '<div class="people_hover">'+
                						'<p class="title">'+element["character"]+'</p>'+
                						'<p class="descripcion"><b>'+element["name"]+'</b></p>'+
                						'<buton class="btnShow" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                					'</div>'+
                                '</article>';
                });
                contActors.innerHTML=person;

                //var director=credits.crew.find(element=>element.job=="Director");
                let crews='';
                credits.crew.forEach(element =>{
                    crews+=setArticleCrew(element);
                });
                //var story=credits.crew.find(element=>element.job=="Story");
                contCrews.innerHTML=crews;

                const btnShowPerson=document.querySelectorAll(".btnShow");
                    btnShowPerson.forEach(btn =>{
                    	btn.addEventListener("click",({target: {dataset}}) => {
                            localStorage.personid=dataset.id;
                    		window.location.href = "../htmls/infoPerson.html";
                    	})
                    });

        }else{
            alert(result.type+": "+result.code+", "+result.message);
        }
}
function setArticleCrew(person){
        let image;
        if(person["profile_path"]==null){
            image=img_not_found;
        }else{
            image="https://image.tmdb.org/t/p/original/"+person["profile_path"];
        }
    return '<article class="people">'+
                       '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                       '<div class="people_hover">'+
                           '<p class="title">'+person["name"]+'</p>'+
                           '<p class="descripcion"><b>'+person["job"]+'</b></p>'+
                           '<buton class="btnShow" data-id="'+person["id"]+'">INFORMACI&Oacute;N</buton>'+
                       '</div>'+
                   '</article>';
}