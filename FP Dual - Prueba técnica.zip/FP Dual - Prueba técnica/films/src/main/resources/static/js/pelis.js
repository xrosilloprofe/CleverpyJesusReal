import { ajax } from "./ajax.js";
var cliente;

var filter=false;

const cont_pelis= document.querySelector("#cont_pelis");
const numPage=document.querySelector("#numPage");
const searchPage=document.querySelector("#searchPage");
const txtTitleFilter=document.querySelector("#txtTitleFilter");
const txtDescripcionFilter=document.querySelector("#txtDescripcionFilter");
const genFilter=document.querySelector("#genFilter");
const btnFilter=document.querySelector("#btnFilter");

searchPage.addEventListener("click",
         async function(){
            if(filter){
                await filterMovies();
            }else{
                await searchFilms();
            }
        });

btnFilter.addEventListener("click",async function(){
                                       numPage.max=1;
                                       numPage.min=1;
                                       numPage.value=1;
                                       await filterMovies();
                                   });



const show_cont_filter=document.querySelector("#show_cont_filter");

const cont_filtros=document.querySelector("#cont_filtros");
var URLactual = window.location;
if(typeof show_cont_filter !== 'undefined' || show_cont_filter !=null){
    show_cont_filter.addEventListener("click",seeFilters);
}
function seeFilters(){

	var text=show_cont_filter.textContent;
	if (text=="FILTROS ✔"){
		show_cont_filter.textContent='FILTROS X';
		cont_filtros.style.left="0%";
	}else{
		show_cont_filter.textContent='FILTROS ✔';
		cont_filtros.style.left="-100%";
	}

}
searchFilms();


async function searchFilms(){

    if(numPage.value>numPage.max){
        numPage.value=numPage.max;
    }
    if(numPage.value>500){
        numPage.value=500;
     }

     let url='api/films/'+numPage.value;
     ajax({
             url: url,
             // method: 'GET',
             // async: true,
             // responseType: 'json',
             done: setFilms,
             error: errorMesage,
       })

}


async function errorMesage(status){
    alert(status);
}
async function setFilms(result){
    if(result.type=='SUCCESS'){
                let peliculas=result.info;
        		let addPelis='';
                    peliculas.results.forEach(element =>{

                    	addPelis+='<article class="peli">'+
                                        '<div class="img" style="background-image: url(\'https://image.tmdb.org/t/p/original/'+element["backdrop_path"]+'\')"> </div>'+
                                        '<div class="peli_hover">'+
                    						'<p class="title">'+element["title"]+'</p>'+
                    						'<p class="descripcion"><b>'+element["overview"]+'</b></p>'+
                    						'<buton class="btnShowFilm" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                    					'</div>'+
                                    '</article>';
                    });
                    cont_pelis.innerHTML=addPelis;

                    if(peliculas.total_pages>500){
                        numPage.max=500;
                     }else{
                        numPage.max=peliculas.total_pages;
                     }

                    const btns_reserva=document.querySelectorAll(".btnShowFilm");

                    btns_reserva.forEach(btn =>{
                    	btn.addEventListener("click",({target: {dataset}}) => {
                            localStorage.peliid=dataset.id;
                    		window.location.href = "../htmls/infoPeli.html";
                    	})
                    });
        }else{
            alert(result.type+": "+result.code+", "+result.message);
        }
}

async function filterMovies(){
  var title=txtTitleFilter.value;
  var year=txtDescripcionFilter.value;
  var lenguage=genFilter.options[genFilter.selectedIndex].value;

  if(year.length === 0){
    year="null";
  }
  if(title.length === 0){
      title="null";
  }
  if(numPage.value>numPage.max){
        numPage.value=numPage.max;
  }
  if(numPage.value>500){
        numPage.value=500;
  }

  const url='/api/films/'+title+'/'+lenguage+'/'+year+'/'+numPage.value;

  ajax({
        url: url,
        // method: 'GET',
        // async: true,
        // responseType: 'json',
        done: setFilms,
        error: errorMesage,
  })

  filter=true;
}


