const imgLike='http://localhost:8080/img/with_like.png';
const imgNoLike='http://localhost:8080/img/without_like.png';
const img_not_found="http://assets.stickpng.com/images/5a461402d099a2ad03f9c997.png";
var person;
var idPerson=localStorage.personid;

const like=document.querySelector("#like");

const titleFilm=document.querySelector("#titleArticle");
const birthday=document.querySelector("#subtitle");
const person_img=document.querySelector("#article_img");
const descripcion=document.querySelector("#overview");
const contActors=document.querySelector("#list1");
if (typeof idPerson !== 'undefined'){
    setInfoPerson();
}else{
    window.location.href = "../index.html";
}
async function setInfoPerson(){

    var url='http://localhost:8080/api/person/'+idPerson;
    var request = await fetch(url, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
        });
        var result = await request.json();

         if(result.type=='SUCCESS'){
            person=result.info;
            await obtenerDatos();
        }else{
            alert(result.type+": "+result.code+", "+result.message);
        }
}

async function obtenerDatos() {
	titleFilm.textContent=person["name"]+" - "+person["known_for_department"];
	birthday.textContent=person["birthday"];
	person_img.src="https://image.tmdb.org/t/p/original/" + person["profile_path"];
	descripcion.textContent=person["biography"];

    like.src=imgNoLike;

    if (typeof sessionStorage.token !== 'undefined') {
        const url='http://localhost:8080/api/user/getLike/'+person["id"];

        var request = await fetch(url, {
           method: 'GET',
           headers: {
             'Accept': 'application/json',
             'Content-Type': 'application/json',
             'Authorization':sessionStorage.token
           },
         });

         const result = await request.json();

         if(result.type=='SUCCESS'){
            if(result.info==true){
                like.src=imgLike;
            }else{
                like.src=imgNoLike;
            }
         }else{
             alert(result.type+": "+result.code+", "+result.message);
         }

        like.addEventListener("click",setLike);
    }
	setCredits();
}

async function setLike(){
        if (typeof sessionStorage.token !== 'undefined') {
        	const url='http://localhost:8080/api/user/setLike/'+person["id"]+'/PERSON';

                    var request = await fetch(url, {
                       method: 'GET',
                       headers: {
                         'Accept': 'application/json',
                         'Content-Type': 'application/json',
                         'Authorization':sessionStorage.token
                       },
                     });

                     const result = await request.json();
                     if(result.type=='SUCCESS'){
                        if(like.src==imgLike){
                            like.src=imgNoLike
                        }else{
                            like.src=imgLike;
                        }
                     }else{
                         alert(result.type+": "+result.code+", "+result.message);
                     }
        }else{
            alert("Necesitas iniciar sesion");
        }

}

async function setCredits(){
    var url='http://localhost:8080/api/personMovies/'+idPerson;
    var request = await fetch(url, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
        });
        var result = await request.json();

         if(result.type=='SUCCESS'){
            var credits=result.info;
            let person='';
            let image;
            credits.cast.forEach(element =>{
                    if(element["poster_path"]==null){
                        image=img_not_found;
                    }else{
                        image="https://image.tmdb.org/t/p/original/"+element["poster_path"];
                    }
                	person+='<article class="people">'+
                                    '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                                    '<div class="people_hover">'+
                						'<p class="title">'+element["title"]+'</p>'+
                						'<p class="descripcion"><b>'+element["character"]+'</b></p>'+
                						'<buton class="btnShow" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                					'</div>'+
                                '</article>';


                });
                credits.crew.forEach(element =>{
                    if(element["poster_path"]==null){
                        image=img_not_found;
                    }else{
                        image="https://image.tmdb.org/t/p/original/"+element["poster_path"];
                    }
                        person+='<article class="people">'+
                                        '<div class="img" style="background-image: url(\''+image+'\')"> </div>'+
                                        '<div class="people_hover">'+
                                            '<p class="title">'+element["title"]+'</p>'+
                                            '<p class="descripcion"><b>'+element["department"]+'</b></p>'+
                                            '<buton class="btnShow" data-id="'+element["id"]+'">INFORMACI&Oacute;N</buton>'+
                                        '</div>'+
                                    '</article>';


                    });
                contActors.innerHTML=person;


                const btnShowPerson=document.querySelectorAll(".btnShow");
                    btnShowPerson.forEach(btn =>{
                    	btn.addEventListener("click",({target: {dataset}}) => {
                            localStorage.peliid=dataset.id;
                    		window.location.href = "../htmls/infoPeli.html";
                    	})
                    });

        }else{
            alert(result.type+": "+result.code+", "+result.message);
        }
}

