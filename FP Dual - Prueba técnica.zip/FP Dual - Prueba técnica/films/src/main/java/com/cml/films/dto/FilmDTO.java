package com.cml.films.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.ArrayList;

@Entity
@Table(name = "films")
@ToString @EqualsAndHashCode
public class FilmDTO {
    private String poster_path;
    @Getter @Column(name = "adult")
    private boolean adult;
    @Getter @Column(name = "overview")
    private String overview;
    @Getter @Column(name = "release_date")
    private String release_date;
    @Getter @Column(name = "genre_ids")
    private ArrayList<Integer> genre_ids;
    @Getter @Column(name = "id")
    @Id
    private int id;
    @Getter @Column(name = "original_title")
    private String original_title;
    @Getter @Column(name = "language")
    private String original_language;
    @Getter @Column(name = "title")
    private String title;
    @Getter @Column(name = "backdrop_path")
    private String backdrop_path;
    @Getter @Column(name = "popularity")
    private double popularity;
    @Getter @Column(name = "vote_content")
    private int vote_count;
    @Getter @Column(name = "video")
    private boolean video;
    @Getter @Column(name = "vote_average")
    private double vote_average;


    public FilmDTO(String poster_path, boolean adult, String overview, String release_date, ArrayList<Integer> genre_ids, int id, String original_title, String original_language, String title, String backdrop_path, double popularity, int vote_count, boolean video, double vote_average) {
        this.poster_path = poster_path;
        this.adult = adult;
        this.overview = overview;
        this.release_date = release_date;
        this.genre_ids = genre_ids;
        this.id = id;
        this.original_title = original_title;
        this.original_language = original_language;
        this.title = title;
        this.backdrop_path = backdrop_path;
        this.popularity = popularity;
        this.vote_count = vote_count;
        this.video = video;
        this.vote_average = vote_average;
    }


}
