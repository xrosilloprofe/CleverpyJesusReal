package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;

@ToString
public class FilmWHEIDTO{
    @Getter
    private boolean adult;
    @Getter
    private String backdrop_path;
    @Getter
    private Object belongs_to_collection;
    @Getter
    private int budget;
    @Getter
    private ArrayList<Genre> genres;
    @Getter
    private String homepage;
    @Getter
    private int id;
    @Getter
    private String imdb_id;
    @Getter
    private String original_language;
    @Getter
    private String original_title;
    @Getter
    private String overview;
    @Getter
    private double popularity;
    @Getter
    private String poster_path;
    @Getter
    private ArrayList<ProductionCompany> production_companies;
    @Getter
    private ArrayList<ProductionCountry> production_countries;
    @Getter
    private String release_date;
    @Getter
    private int revenue;
    @Getter
    private int runtime;
    @Getter
    private ArrayList<SpokenLanguage> spoken_languages;
    @Getter
    private String status;
    @Getter
    private String tagline;
    @Getter
    private String title;
    @Getter
    private boolean video;
    @Getter
    private double vote_average;
    @Getter
    private int vote_count;

    @ToString
    private static class Genre{
        @Getter
        private int id;
        @Getter
        private String name;

        public Genre(int id, String name) {

            this.id = id;
            this.name = name;
        }
    }
    @ToString
    private static class ProductionCompany{
        @Getter
        private int id;
        @Getter
        private String logo_path;
        @Getter
        private String name;
        @Getter
        private String origin_country;

        public ProductionCompany(int id, String logo_path, String name, String origin_country) {
            this.id = id;
            this.logo_path = logo_path;
            this.name = name;
            this.origin_country = origin_country;
        }
    }
    @ToString
    private static class ProductionCountry{
        @Getter
        private String iso_3166_1;
        @Getter
        private String name;

        public ProductionCountry(String iso_3166_1, String name) {
            this.iso_3166_1 = iso_3166_1;
            this.name = name;
        }
    }

    @ToString
    private static class SpokenLanguage{
        @Getter
        private String english_name;
        @Getter
        private String iso_639_1;
        @Getter
        private String name;

        public SpokenLanguage(String english_name, String iso_639_1, String name) {
            this.english_name = english_name;
            this.iso_639_1 = iso_639_1;
            this.name = name;
        }
    }
}
