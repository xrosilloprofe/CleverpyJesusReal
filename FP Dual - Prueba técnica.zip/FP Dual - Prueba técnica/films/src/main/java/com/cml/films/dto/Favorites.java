package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@ToString
public class Favorites {
    @Getter
    private ArrayList<FilmWHEIDTO> films;
    @Getter
    private ArrayList<PersonDTO>  persons;
    @Getter
    private int id_user;

    public Favorites(ArrayList<FilmWHEIDTO> films, ArrayList<PersonDTO> persons, int id_user) {
        this.films = films;
        this.persons = persons;
        this.id_user = id_user;
    }
}
