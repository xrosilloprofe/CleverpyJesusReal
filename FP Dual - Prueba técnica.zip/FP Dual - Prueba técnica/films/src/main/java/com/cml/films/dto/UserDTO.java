package com.cml.films.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;

@Entity
@Table(name = "usuarios")
@ToString @EqualsAndHashCode
public class UserDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter @Column(name = "id")
    private int id;
    @Getter @Column(name = "usuario")
    private String usuario;
    @Getter @Column(name = "email")
    private String email;
    @Getter @Setter
    @Column(name = "password")
    private String password;



}
