package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;

@ToString
public class PersonDTO {
    @Getter
    private String birthday;
    @Getter
    private String known_for_department;
    @Getter
    public String deathday;
    @Getter
    private int id;
    @Getter
    private String name;
    @Getter
    private ArrayList<String> also_known_as;
    @Getter
    private int gender;
    @Getter
    private String biography;
    @Getter
    private double popularity;
    @Getter
    private String place_of_birth;
    @Getter
    private String profile_path;
    @Getter
    private boolean adult;
    @Getter
    private String imdb_id;
    @Getter
    private String homepage;

    public PersonDTO(String birthday, String known_for_department, String deathday, int id, String name, ArrayList<String> also_known_as, int gender, String biography, double popularity, String place_of_birth, String profile_path, boolean adult, String imdb_id, String homepage) {
        this.birthday = birthday;
        this.known_for_department = known_for_department;
        this.deathday = deathday;
        this.id = id;
        this.name = name;
        this.also_known_as = also_known_as;
        this.gender = gender;
        this.biography = biography;
        this.popularity = popularity;
        this.place_of_birth = place_of_birth;
        this.profile_path = profile_path;
        this.adult = adult;
        this.imdb_id = imdb_id;
        this.homepage = homepage;
    }
}
