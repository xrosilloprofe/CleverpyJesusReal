package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;


@ToString
public class CreditsFilmDTO {
    @Getter
    private int id;
    @Getter
    private ArrayList<Cast> cast;
    @Getter
    private ArrayList<Crew> crew;

    public CreditsFilmDTO(int id, ArrayList<Cast> cast, ArrayList<Crew> crew) {
        this.id = id;
        this.cast = cast;
        this.crew = crew;
    }

    @ToString
    private static class Cast{
        @Getter
        private boolean adult;
        @Getter
        private int gender;
        @Getter
        private int id;
        @Getter
        private String known_for_department;
        @Getter
        private String name;
        @Getter
        private String original_name;
        @Getter
        private double popularity;
        @Getter
        private String profile_path;
        @Getter
        private int cast_id;
        @Getter
        private String character;
        @Getter
        private String credit_id;
        @Getter
        private int order;

        public Cast(boolean adult, int gender, int id, String known_for_department, String name, String original_name, double popularity, String profile_path, int cast_id, String character, String credit_id, int order) {
            this.adult = adult;
            this.gender = gender;
            this.id = id;
            this.known_for_department = known_for_department;
            this.name = name;
            this.original_name = original_name;
            this.popularity = popularity;
            this.profile_path = profile_path;
            this.cast_id = cast_id;
            this.character = character;
            this.credit_id = credit_id;
            this.order = order;
        }
    }

    @ToString
    private  static class Crew{
        @Getter
        private boolean adult;
        @Getter
        private int gender;
        @Getter
        private int id;
        @Getter
        private String known_for_department;
        @Getter
        private String name;
        @Getter
        private String original_name;
        @Getter
        private double popularity;
        @Getter
        private String profile_path;
        @Getter
        private String credit_id;
        @Getter
        private String department;
        @Getter
        private String job;

        public Crew(boolean adult, int gender, int id, String known_for_department, String name, String original_name, double popularity, String profile_path, String credit_id, String department, String job) {
            this.adult = adult;
            this.gender = gender;
            this.id = id;
            this.known_for_department = known_for_department;
            this.name = name;
            this.original_name = original_name;
            this.popularity = popularity;
            this.profile_path = profile_path;
            this.credit_id = credit_id;
            this.department = department;
            this.job = job;
        }
    }
}
