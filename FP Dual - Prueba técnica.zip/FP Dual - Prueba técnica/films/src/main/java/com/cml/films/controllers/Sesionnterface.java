package com.cml.films.controllers;

import com.cml.films.utils.Result;

public interface Sesionnterface<T> {
    Result register(T user);
    Result loggin( String user, String password);

    Result getUser(String token);
    }
