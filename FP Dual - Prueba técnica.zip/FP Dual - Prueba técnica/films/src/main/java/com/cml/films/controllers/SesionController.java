package com.cml.films.controllers;

import com.cml.films.api.Films;
import com.cml.films.api.Parameters;
import com.cml.films.api.Users;
import com.cml.films.dto.*;
import com.cml.films.utils.JWTUtil;
import com.cml.films.utils.Result;
import io.restassured.RestAssured;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@RestController
public class SesionController implements Sesionnterface<UserDTO> {

    @Autowired
    Users users;

    @Autowired
    Films films;

    @Autowired
    JWTUtil jwt;

    @Override
    @RequestMapping(value = "api/register", method = RequestMethod.POST)
    public Result register(@RequestBody UserDTO user) {
        UserDTO u=users.findByEmail(user.getEmail());
        if (u==null){
            users.registrar(user);
            return new Result.Success<UserDTO>(u);
        }else{
            return new Result.Error(402,"Email ya existe");
        }

    }

    @Override
    @RequestMapping(value = "api/login/{user}/{password}")
    public Result loggin(@PathVariable String user, @PathVariable String password) {
        UserDTO u=users.login(user,password);
        if (u!=null){
            String token =jwt.create(u.getId()+"",u.getEmail());
            return new Result.Success<String>(token);
        }else{
            return new Result.Error(401,"Error identificacion");
        }

    }

    @Override
    @RequestMapping(value = "api/getUser", method = RequestMethod.GET)
    public Result getUser(@RequestHeader(value = "Authorization")String token) {
        try{
            String email=jwt.getValue(token);
            UserDTO user=users.findByEmail(email);
            if(user==null){
                return new Result.Error(403,"Usuario no existe");
            }
            return new Result.Success<UserDTO>(users.findByEmail(email));
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());

        }

    }
    @RequestMapping(value = "api/user/setLike/{id}/{type}", method = RequestMethod.GET)
    public Result setLike(@RequestHeader(value = "Authorization")String token,@PathVariable int id,@PathVariable String type) {
        try{
            boolean result;
            String email=jwt.getValue(token);
            UserDTO user=users.findByEmail(email);
            if(user==null){
                return new Result.Error(403,"Usuario no existe");
            }
            if (type.equals(CestaDTO.TypeArticle.FILM.name())){
                result=users.setLike(user,id,CestaDTO.TypeArticle.FILM);
            } else if (type.equals(CestaDTO.TypeArticle.PERSON.name())) {
                result=users.setLike(user,id,CestaDTO.TypeArticle.PERSON);
            }else{
                return new Result.Error(404,"Articulo "+type+"no existe");
            }
            return new Result.Success<Boolean>(result);
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());

        }

    }


    @RequestMapping(value = "api/user/getLike/{id}", method = RequestMethod.GET)
    public Result getLike(@RequestHeader(value = "Authorization")String token,@PathVariable int id) {
        try{
            String email=jwt.getValue(token);
            UserDTO user=users.findByEmail(email);
            if(user==null){
                return new Result.Error(403,"Usuario no existe");
            }
            List<CestaDTO> result=users.findArticle(user.getId(), id);
            if (!result.isEmpty()){
                return new Result.Success<Boolean>(true);
            }else{
                return new Result.Success<Boolean>(false);

            }
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());

        }

    }

    @RequestMapping(value = "api/user/getFavorites", method = RequestMethod.GET)
    public Result getFavorites(@RequestHeader(value = "Authorization")String token) {
        try{
            String email=jwt.getValue(token);
            UserDTO user=users.findByEmail(email);
            if(user==null){
                return new Result.Error(403,"Usuario no existe");
            }
            List<CestaDTO> result=users.getArticles(user.getId());
            System.out.println(result);
            if (!result.isEmpty()){
                ArrayList<FilmWHEIDTO> films= getFavoriteFilms(result.stream().filter(article->article.getType().equals(CestaDTO.TypeArticle.FILM.name()))
                                                                .map(id->id.getId_article())
                                                                .collect(Collectors.toList()));

                ArrayList<PersonDTO> persons=getFavoritePersons(result.stream().filter(article->article.getType().equals(CestaDTO.TypeArticle.PERSON.name()))
                        .map(id->id.getId_article())
                        .collect(Collectors.toList()));
                Favorites favorites=new Favorites(films,persons,user.getId());
                return new Result.Success<Favorites>(favorites);
            }else{
                return new Result.Error(404,"No hay elementos");
            }
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }

    }

    private ArrayList<PersonDTO> getFavoritePersons(List<Integer> ids) {
        ArrayList<PersonDTO> persons=new ArrayList<PersonDTO>();
        System.out.println();
        String url;
        for(Integer id:ids){
            url=Parameters.URL_PERSON+id+"?api_key="+Parameters.API_KEY;
            try{
                PersonDTO person= RestAssured.get(url).as(PersonDTO.class);
                if(person!=null) persons.add(person);
            }catch (Exception e){

            }
        }
        return persons;
    }

    private ArrayList<FilmWHEIDTO> getFavoriteFilms(List<Integer> ids) {
        ArrayList<FilmWHEIDTO> films=new ArrayList<FilmWHEIDTO>();
        String path;
        for(Integer id:ids){
             path="https://api.themoviedb.org/3/movie/"+id+"?api_key="+ Parameters.API_KEY;
            try{
                FilmWHEIDTO movie= RestAssured.get(path).as(FilmWHEIDTO.class);
                if(movie!=null) films.add(movie);
            }catch (Exception e){

            }
        }
        return films;
    }



}
