package com.cml.films.utils;

import lombok.Getter;

public class Result <T>{
    @Getter
    private TypeResult type;

    public Result(TypeResult type){
        this.type=type;
    }
    public static class Success<T> extends Result {
        @Getter
        private T info;

        public Success(T info){
            super(TypeResult.SUCCESS);
            this.info=info;
        }
    }
    public static class Error extends Result {
        @Getter
        private int code;
        @Getter
        private String message;

        public Error(int code,String message){
            super(TypeResult.ERROR);
            this.code=code;
            this.message=message;
        }
    }
    public enum TypeResult{
        SUCCESS,ERROR
    }
}
