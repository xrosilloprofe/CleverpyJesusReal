package com.cml.films.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

public class MovieApiDTO {
    @Getter @Setter
    private int page;
    @Getter @Setter
    private ArrayList<FilmDTO> results;
    @Getter @Setter
    private int total_results;
    @Getter @Setter
    private int total_pages;


}
