package com.cml.films.controllers;

import com.cml.films.utils.Result;

public interface PersonInterface<T,V> {

    Result<T> getPerson(int id);
    Result<V> getCredits(int id);

    }
