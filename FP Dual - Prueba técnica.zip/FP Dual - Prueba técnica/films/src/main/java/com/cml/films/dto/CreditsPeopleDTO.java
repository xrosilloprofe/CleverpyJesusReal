package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;

@ToString
public class CreditsPeopleDTO{
    @Getter
    private ArrayList<Cast> cast;
    @Getter
    private ArrayList<Crew> crew;
    @Getter
    private int id;

    public CreditsPeopleDTO(ArrayList<Cast> cast, ArrayList<Crew> crew, int id) {
        this.cast = cast;
        this.crew = crew;
        this.id = id;
    }

    @ToString
    private static class Cast{
        @Getter
        private ArrayList<Integer> genre_ids;
        @Getter
        private String original_language;
        @Getter
        private String original_title;
        @Getter
        private String poster_path;
        @Getter
        private String title;
        @Getter
        private boolean video;
        @Getter
        private double vote_average;
        @Getter
        private String overview;
        @Getter
        private String release_date;
        @Getter
        private int vote_count;
        @Getter
        private boolean adult;
        @Getter
        private String backdrop_path;
        @Getter
        private int id;
        @Getter
        private double popularity;
        @Getter
        private String character;
        @Getter
        private String credit_id;
        @Getter
        private int order;

        public Cast(ArrayList<Integer> genre_ids, String original_language, String original_title, String poster_path, String title, boolean video, double vote_average, String overview, String release_date, int vote_count, boolean adult, String backdrop_path, int id, double popularity, String character, String credit_id, int order) {
            this.genre_ids = genre_ids;
            this.original_language = original_language;
            this.original_title = original_title;
            this.poster_path = poster_path;
            this.title = title;
            this.video = video;
            this.vote_average = vote_average;
            this.overview = overview;
            this.release_date = release_date;
            this.vote_count = vote_count;
            this.adult = adult;
            this.backdrop_path = backdrop_path;
            this.id = id;
            this.popularity = popularity;
            this.character = character;
            this.credit_id = credit_id;
            this.order = order;
        }
    }

    @ToString
    private static class Crew{
        @Getter
        private boolean adult;
        @Getter
        private String backdrop_path;
        @Getter
        private ArrayList<Integer> genre_ids;
        @Getter
        private int id;
        @Getter
        private String original_language;
        @Getter
        private String original_title;
        @Getter
        private String overview;
        @Getter
        private String poster_path;
        @Getter
        private String release_date;
        @Getter
        private String title;
        @Getter
        private boolean video;
        @Getter
        private double vote_average;
        @Getter
        private int vote_count;
        @Getter
        private double popularity;
        @Getter
        private String credit_id;
        @Getter
        private String department;
        @Getter
        private String job;

        public Crew(boolean adult, String backdrop_path, ArrayList<Integer> genre_ids, int id, String original_language, String original_title, String overview, String poster_path, String release_date, String title, boolean video, double vote_average, int vote_count, double popularity, String credit_id, String department, String job) {
            this.adult = adult;
            this.backdrop_path = backdrop_path;
            this.genre_ids = genre_ids;
            this.id = id;
            this.original_language = original_language;
            this.original_title = original_title;
            this.overview = overview;
            this.poster_path = poster_path;
            this.release_date = release_date;
            this.title = title;
            this.video = video;
            this.vote_average = vote_average;
            this.vote_count = vote_count;
            this.popularity = popularity;
            this.credit_id = credit_id;
            this.department = department;
            this.job = job;
        }
    }

}
