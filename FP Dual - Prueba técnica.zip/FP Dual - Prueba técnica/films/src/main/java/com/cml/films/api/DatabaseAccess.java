package com.cml.films.api;

import java.util.List;
import java.util.Map;

public interface DatabaseAccess<T>{

    List<T> select(String sql);

    T insert(T data);

    //T update( T data);

    void delete(int id);

}
