package com.cml.films.api;

import com.cml.films.dto.UserDTO;

public interface UsersInterfaz<T>{
    UserDTO findByEmail(String email);
    void registrar(T user);
    T login(String email,String password);

}
