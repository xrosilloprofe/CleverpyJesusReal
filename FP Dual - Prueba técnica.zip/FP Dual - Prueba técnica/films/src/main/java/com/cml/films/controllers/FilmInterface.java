package com.cml.films.controllers;

import com.cml.films.dto.MovieApiDTO;
import com.cml.films.utils.Result;
import org.springframework.web.bind.annotation.PathVariable;

public interface FilmInterface<T> {
    T getFilms(int page);
    T getFilms( String titulo, String descripcion, String genero, int page);
    Result getFilm(int id);
    Result getCredits(int id);

    }
