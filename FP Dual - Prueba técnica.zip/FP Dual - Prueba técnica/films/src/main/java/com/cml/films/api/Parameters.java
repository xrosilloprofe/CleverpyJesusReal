package com.cml.films.api;

public class Parameters {
    public static final String URL="https://api.themoviedb.org/3/";
    public static final String API_KEY="9fe197eb7caf665d50309e0adbcf5ede";
    public static final String URL_DISCOVER ="https://api.themoviedb.org/3/discover/movie?api_key="+API_KEY;
    public static final String URL_SEARCH_FILM="https://api.themoviedb.org/3/search/movie?api_key="+API_KEY;
    public static final String URL_PERSON="https://api.themoviedb.org/3/person/";
}
