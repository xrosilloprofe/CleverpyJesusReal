package com.cml.films.api;

import com.cml.films.dto.CestaDTO;
import com.cml.films.dto.UserDTO;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional
public class Users implements DatabaseAccess<UserDTO>, UsersInterfaz<UserDTO> {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<UserDTO> select(String sql) {
        return entityManager.createQuery(sql).getResultList();
    }

    @Override
    public UserDTO insert(UserDTO data) {
        return null;
    }

    @Override
    public void delete(int id) {
        entityManager.remove(entityManager.find(UserDTO.class,id));
    }

    @Override
    public void registrar(UserDTO user) {
        Argon2 argon2= Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
        String hash=argon2.hash(1,1024,1,user.getPassword());
        user.setPassword(hash);
        entityManager.merge(user);
    }

    @Override
    public UserDTO login(String email,String password) {
        Argon2 argon2= Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
        UserDTO user=findByEmail(email);
        if (user!=null){
            if (argon2.verify(user.getPassword(),password)){
                return user;
            }
        }
        return null;
    }

    @Override
    public UserDTO findByEmail(String email){
        String query="from UserDTO where email = :email ";
        List<UserDTO> userList=entityManager.createQuery(query)
                .setParameter("email",email)
                .getResultList();

       return (userList.isEmpty())?null: userList.get(0);
    }

    public List<CestaDTO> findArticle(int userId, int articleId) {
        String query="from CestaDTO where id_user = :id_user and id_article = :id_article";
        return entityManager.createQuery(query)
                .setParameter("id_user",userId)
                .setParameter("id_article",articleId)
                .getResultList();
    }
    public List<CestaDTO> getArticles(int userId) {
        String query="from CestaDTO where id_user = :id_user";
        return entityManager.createQuery(query)
                .setParameter("id_user",userId)
                .getResultList();
    }
    public Boolean setLike(UserDTO user, int filmId, CestaDTO.TypeArticle type) {
        String query="from CestaDTO where id_user = :id_user and id_article = :id_article";
        List<CestaDTO> list=findArticle(user.getId(), filmId);

        if (!list.isEmpty()){
            entityManager.remove(list.get(0));
            return false;
        }else{
            CestaDTO cesta=new CestaDTO();
            cesta.setId_user(user.getId());
            cesta.setId_article(filmId);
            cesta.setType(type.name());
            entityManager.merge(cesta);
            return true;
        }

    }
}
