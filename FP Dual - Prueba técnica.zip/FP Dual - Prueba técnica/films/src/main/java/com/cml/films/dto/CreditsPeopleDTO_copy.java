package com.cml.films.dto;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;

@ToString
public class CreditsPeopleDTO_copy {
    @Getter
    private ArrayList<Cast> cast;
    @Getter
    private ArrayList<Crew> crew;
    @Getter
    private int id;


    @ToString
    private static class Cast{
        @Getter
        private String character;
        @Getter
        private String credit_id;
        @Getter
        private String release_date;
        @Getter
        private int vote_count;
        @Getter
        private boolean video;
        @Getter
        private boolean adult;
        @Getter
        private double vote_average;
        @Getter
        private String title;
        @Getter
        private ArrayList<Integer> genre_ids;
        @Getter
        private String original_language;
        @Getter
        private String original_title;
        @Getter
        private double popularity;
        @Getter
        private int id;
        @Getter
        private String backdrop_path;
        @Getter
        private String overview;
        @Getter
        private String poster_path;

        public Cast(String character, String credit_id, String release_date, int vote_count, boolean video, boolean adult, double vote_average, String title, ArrayList<Integer> genre_ids, String original_language, String original_title, double popularity, int id, String backdrop_path, String overview, String poster_path) {
            this.character = character;
            this.credit_id = credit_id;
            this.release_date = release_date;
            this.vote_count = vote_count;
            this.video = video;
            this.adult = adult;
            this.vote_average = vote_average;
            this.title = title;
            this.genre_ids = genre_ids;
            this.original_language = original_language;
            this.original_title = original_title;
            this.popularity = popularity;
            this.id = id;
            this.backdrop_path = backdrop_path;
            this.overview = overview;
            this.poster_path = poster_path;
        }
    }

    @ToString
    private static class Crew{
        @Getter
        private int id;
        @Getter
        private String department;
        @Getter
        private String original_language;
        @Getter
        private String original_title;
        @Getter
        private String job;
        @Getter
        private String overview;
        @Getter
        private int vote_count;
        @Getter
        private boolean video;
        @Getter
        private String poster_path;
        @Getter
        private String backdrop_path;
        @Getter
        private String title;
        @Getter
        private double popularity;
        @Getter
        private ArrayList<Integer> genre_ids;
        @Getter
        private double vote_average;
        @Getter
        private boolean adult;
        @Getter
        private String release_date;
        @Getter
        private String credit_id;

        public Crew(int id, String department, String original_language, String original_title, String job, String overview, int vote_count, boolean video, String poster_path, String backdrop_path, String title, double popularity, ArrayList<Integer> genre_ids, double vote_average, boolean adult, String release_date, String credit_id) {
            this.id = id;
            this.department = department;
            this.original_language = original_language;
            this.original_title = original_title;
            this.job = job;
            this.overview = overview;
            this.vote_count = vote_count;
            this.video = video;
            this.poster_path = poster_path;
            this.backdrop_path = backdrop_path;
            this.title = title;
            this.popularity = popularity;
            this.genre_ids = genre_ids;
            this.vote_average = vote_average;
            this.adult = adult;
            this.release_date = release_date;
            this.credit_id = credit_id;
        }
    }

}


