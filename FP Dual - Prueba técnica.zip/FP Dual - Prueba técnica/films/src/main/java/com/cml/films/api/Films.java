package com.cml.films.api;

import com.cml.films.dto.FilmDTO;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional
public class Films  implements DatabaseAccess<FilmDTO>{

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public List<FilmDTO> select(String sql) {
        return entityManager.createQuery(sql).getResultList();
    }

    @Override
    public FilmDTO insert(FilmDTO data) {
        return null;
    }

    @Override
    public void delete(int id) {
        entityManager.remove(entityManager.find(FilmDTO.class,id));
    }


}
