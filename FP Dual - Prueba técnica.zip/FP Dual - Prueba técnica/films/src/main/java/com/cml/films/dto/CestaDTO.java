package com.cml.films.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;

@Entity
@Table(name = "cesta")
@ToString
@EqualsAndHashCode
public class CestaDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter @Column(name = "id")
    private int id;
    @Getter @Setter @Column(name = "id_user")
    private int id_user;
    @Getter @Setter @Column(name = "id_article")
    private int id_article;
    @Getter @Setter @Column(name = "type")
    private String type;



    public enum TypeArticle{
        FILM,PERSON
    }
}

