package com.cml.films.controllers;

import com.cml.films.api.Films;
import com.cml.films.api.Parameters;
import com.cml.films.dto.CreditsFilmDTO;
import com.cml.films.dto.FilmDTO;
import com.cml.films.dto.FilmWHEIDTO;
import com.cml.films.dto.MovieApiDTO;
import com.cml.films.utils.Result;
import io.restassured.RestAssured;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@RestController
public class FilmsController implements FilmInterface{

    @Autowired
    Films films;

    @CrossOrigin(origins = "http://localhost:8082")
    @RequestMapping(value = "/api/films/{page}")
    public Result getFilms(@PathVariable int page){
        String path="&page="+page;
        try {
            MovieApiDTO movie=RestAssured.get(Parameters.URL_DISCOVER+path).as(MovieApiDTO.class);
            return (movie!=null)? new Result.Success<MovieApiDTO>(movie): new Result.Error(404,"NO ELEMENTS");
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }

    }
    @Override
    @CrossOrigin(origins = "http://localhost:8082")
    @RequestMapping(value = "/api/film/{id}")
    public Result getFilm(@PathVariable int id){
        String path="https://api.themoviedb.org/3/movie/"+id+"?api_key="+Parameters.API_KEY;
        try{
            FilmWHEIDTO movie=RestAssured.get(path).as(FilmWHEIDTO.class);
            if(movie!=null) return new Result.Success<FilmWHEIDTO>(movie);
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }
        return new Result.Error(404,"Peli no existe");
    }

    @Override
    @RequestMapping(value = "/api/credits/{id}")
    public Result getCredits(@PathVariable int id){
        String path="https://api.themoviedb.org/3/movie/"+id+"/credits?api_key="+Parameters.API_KEY;
        try{
            CreditsFilmDTO credits=RestAssured.get(path).as(CreditsFilmDTO.class);
            if(credits!=null) return new Result.Success<CreditsFilmDTO>(credits);
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }
        return new Result.Error(404,"Peli no existe");
    }

    @RequestMapping(value = "/api/films/{titulo}/{language}/{year}/{page}")
    public Result getFilms(@PathVariable String titulo,@PathVariable String language,@PathVariable String year,@PathVariable int page){
        String url="";
        if(titulo.equals("null"))
            url= Parameters.URL_DISCOVER+"&page="+page;
        else
            url=Parameters.URL_SEARCH_FILM+"&query="+titulo+"&page="+page;
        if(!year.equals("null"))  url+="&year="+year;

        if(!language.equals("null"))  url+="&language="+language;

        try{
            MovieApiDTO movieList=RestAssured.get(url).as(MovieApiDTO.class);

            return new Result.Success<MovieApiDTO>(movieList);
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }

    }
    @RequestMapping(value = "/api/userfilms")
    public List<FilmDTO> getUserFilms(){
        String url="FROM FILMS";
        return films.select(url);
    }


}
