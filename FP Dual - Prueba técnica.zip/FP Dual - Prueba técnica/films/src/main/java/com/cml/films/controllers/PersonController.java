package com.cml.films.controllers;

import com.cml.films.api.Films;
import com.cml.films.api.Parameters;
import com.cml.films.dto.*;
import com.cml.films.utils.Result;
import io.restassured.RestAssured;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PersonController implements PersonInterface<PersonDTO,CreditsPeopleDTO>{

    @Autowired
    Films films;

    @Override
    @RequestMapping(value = "api/person/{id}")
    public Result getPerson(@PathVariable int id){
        String url=Parameters.URL_PERSON+id+"?api_key="+Parameters.API_KEY;
        try{
            PersonDTO person=RestAssured.get(url).as(PersonDTO.class);
            if (person!=null){
                return new Result.Success<PersonDTO>(person);
            }
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());

        }
        return new Result.Error(404,"Persona no existe");
    }

    @Override
    @RequestMapping(value = "api/personMovies/{id}")
    public Result getCredits(@PathVariable int id){
        String url=Parameters.URL_PERSON+id+"/movie_credits?api_key="+Parameters.API_KEY;
        try{
            CreditsPeopleDTO credits=RestAssured.get(url).as(CreditsPeopleDTO.class);
            if(credits!=null) return new Result.Success<CreditsPeopleDTO>(credits);
        }catch (Exception e){
            return new Result.Error(e.hashCode(),e.getMessage());
        }
        return new Result.Error(404,"Peli no existe");
    }


}
